#include<iostream>
#include<fstream>
#include<stdlib.h>
#include<time.h>
using namespace std;
int main()
{
int count=0;
int m,n;
int arr[300][300]={0};
 ofstream file;
 file.open("dataset5.txt");
 while(count<350)
 {
     //srand(time(0));

     m=rand()%300;
    // srand(time(0));
     n=rand()%300;
     if(m==n)
     {
         continue;
     }
     else if(arr[m][n]==1)
     {
         continue;
     }
     else
     {
         arr[m][n]=1;
         file<<m<<" "<<n<<endl;
     }
     count++;
 }




}
