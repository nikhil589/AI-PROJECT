#include <bits/stdc++.h>
using namespace std;
int main() {
  freopen("datasets/fb/facebook_combined.txt","r",stdin);
  freopen("datasets/fb/facebook_combined-small.in","w",stdout);
  int N1, N2;
  while(scanf("%d", &N1) != EOF) {
    scanf("%d", &N2);
    if(N1 < 300 && N2 < 300) cout << N1 << " " << N2 << "\n"; 
  }
}
